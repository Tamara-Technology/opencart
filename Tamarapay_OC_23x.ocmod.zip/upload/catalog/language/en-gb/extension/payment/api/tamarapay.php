<?php
$_['text_success'] = 'Success';
$_['error_permission'] = 'Your credential is invalid or you do not have permission to access the API!';