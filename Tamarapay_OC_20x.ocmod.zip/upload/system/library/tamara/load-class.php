<?php

require_once 'model'.DIRECTORY_SEPARATOR.'command'. DIRECTORY_SEPARATOR .'abstract-command.php';
require_once 'model' .DIRECTORY_SEPARATOR. 'command' .DIRECTORY_SEPARATOR. 'scan-order.php';
require_once 'model' .DIRECTORY_SEPARATOR. 'console-input-output.php';